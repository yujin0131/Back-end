package com.airdnd.back;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import common.Common;
import dao.AirdndRoomDAO;
import service.AirdndRoomService;
import vo.AirdndRoomVO;


@Controller
public class TestController {
	
	/*
	 * @Autowired AirdndRoomService airdndroomService;
	 */
	
	@Autowired
	HttpServletRequest request;
	HttpServletResponse response;

	AirdndRoomDAO airdnd_room_dao;
	
	public void setAirdnd_room_dao(AirdndRoomDAO airdnd_room_dao) {
		this.airdnd_room_dao = airdnd_room_dao;
	}
	
	@RequestMapping("/test")
	public String test(Model model) {
		System.out.println("와썹맨2");
		List<AirdndRoomVO> list = airdnd_room_dao.select();
		System.out.println("와라와롸와");
		model.addAttribute("list", list);
		System.out.println("와썹맨");
		return Common.VIEW_PATH + "test.jsp";
	}

}
