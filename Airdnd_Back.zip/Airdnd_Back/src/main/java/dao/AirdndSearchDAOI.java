package dao;

import java.util.List;

import vo.AirdndSearchVO;

public interface AirdndSearchDAOI {
	
	List<AirdndSearchVO> select();


}
