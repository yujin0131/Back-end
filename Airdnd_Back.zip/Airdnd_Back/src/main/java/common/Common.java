package common;

public class Common {

	public static final String VIEW_PATH = "WEB-INF/views/";

}








