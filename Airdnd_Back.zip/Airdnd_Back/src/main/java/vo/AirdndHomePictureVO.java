package vo;

public class AirdndHomePictureVO {
	private int idx, home_idx;
	private String url;

	public AirdndHomePictureVO() {

	}
	public AirdndHomePictureVO(int idx, int home_idx, String url) {

	}
	
} 
