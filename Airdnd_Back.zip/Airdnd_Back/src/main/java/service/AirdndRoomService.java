package service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.AirdndRoomDAO;
import vo.AirdndRoomVO;

@Service
public class AirdndRoomService implements AirdndRoomServiceI{
	
	@Autowired
	AirdndRoomDAO airdnd_room_dao;
	
	@Override
	public List<AirdndRoomVO> daoserviceconnect(){
		System.out.println("온다ㅏㅏ");
		List<AirdndRoomVO> list = airdnd_room_dao.select();
		System.out.println("안온다");
		return list;
	}

}
