package service;

import java.util.List;

import vo.AirdndRoomVO;

public interface AirdndRoomServiceI {
	
	List<AirdndRoomVO> daoserviceconnect();

}
