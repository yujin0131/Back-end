package service;

import java.util.List;

import vo.AirdndHomeVO;

public interface AirdndHomeServiceI {
	
	List<AirdndHomeVO> homeselect();


}
