package service;

import java.util.List;

import vo.AirdndSearchVO;

public interface AirdndSearchServiceI {
	
	List<AirdndSearchVO> searchselect();


}
